package com.interview.timer;

import java.util.Timer;
import java.util.TimerTask;

public class CheckTimer {
	public CheckTimer() {
		// TODO Auto-generated constructor stub
	}

	public static void start() {
		Timer t = new Timer();
		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

			}
		};

	}

	public static void main(String[] args) {

	}

}
