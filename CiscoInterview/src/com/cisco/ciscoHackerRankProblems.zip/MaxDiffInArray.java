package com.cisco;

public class MaxDiffInArray {
	public static void main(String[] args) {
//		int[] arr = { 2, 3, 10, 2, 4, 8, 1 };
//		int[] arr={7,9,5,6,3,2};
		int[] arr={10,8,7,6,5};
		System.out.println(maxDiff(arr));
	}

	public static int maxDiff(int[] arr) {
		int max = 0;
		int min = 0;

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > arr[max])
				max = i;
			if (arr[i] <= arr[min] && i < max) {
				min = i;
			}
		}

		return (arr[max] - arr[min]) > 0 ? arr[max] - arr[min] : -1 ;
	}
}
