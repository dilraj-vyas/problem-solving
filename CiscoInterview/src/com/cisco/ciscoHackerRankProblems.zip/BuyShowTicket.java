package com.cisco;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class BuyShowTicket {

	public static void main(String[] args) {
		List<Person> list = new ArrayList<Person>();
		list.add(new Person("", 1));
		list.add(new Person("", 1));
		list.add(new Person("", 1));
		list.add(new Person("", 1));
		// list.add(new Person("", 5));
		list.get(0).setName("green");

		Queue<Person> list1 = new LinkedList<Person>(list);
		System.out.println(getTime(list1));
	}

	public static int getTime(Queue<Person> list) {
		int time = 0;
		while (!list.isEmpty()) {
			Person curr = list.poll();
			time++;
			if (curr.getTicketLeft() <= 1 && !curr.getName().isEmpty()) {
				break;
			} else if (curr.getTicketLeft() > 1 && !curr.getName().isEmpty()) {
				list.offer(new Person(curr.getName(), curr.getTicketLeft() - 1));
			} else if (curr.getTicketLeft() > 1) {
				list.offer(new Person("", curr.getTicketLeft() - 1));
			}

		}

		return time;
	}

}

class Person {
	private String name;
	private int ticketLeft;

	public Person(String name, int ticketLeft) {
		this.name = name;
		this.ticketLeft = ticketLeft;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTicketLeft() {
		return ticketLeft;
	}

	public void setTicketLeft(int ticketLeft) {
		this.ticketLeft = ticketLeft;
	}

	

}