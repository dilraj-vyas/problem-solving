package com.cisco;

public class Pangrams {
	public static void main(String[] args) {
		/*
		 * [{(
		 * 
		 * )(
		 * 
		 * )} ({[ ]})] ({ }[({
		 * 
		 * })]) ( ( ( ( ( ( (
		 * 
		 * )[ ])) {
		 * 
		 * }) )[ ]{ { { ( { ( { ( { { { { { { } } } } } } ) } ) } ) } } } ) ) [
		 * ][ ][ ]{
		 */
	}
}
